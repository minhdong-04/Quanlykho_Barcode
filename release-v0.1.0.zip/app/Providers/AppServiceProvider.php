<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register()
    {
        // register app services if needed
    }

    public function boot()
    {
        // boot services if needed
    }
}
